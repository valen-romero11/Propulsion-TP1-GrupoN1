/**
 * ============================================================
 *  charts.js — Visualización con Plotly.js
 *  UTN Haedo · Predimensionamiento de Motores Aeronáuticos
 * ============================================================
 *
 *  Genera:
 *    · Diagrama p-v (escala lineal o log)
 *    · Diagrama T-s
 *    · Curvas paramétricas η / PME / T_max  vs. r
 *    · Comparación de los 3 ciclos en p-v superpuesto
 *
 *  Convención de colores por ciclo:
 *    Otto    → #FF0066  (fucsia — color del TP)
 *    Diesel  → #1F78B4  (azul técnico)
 *    Sabathé → #33A02C  (verde)
 * ============================================================
 */

'use strict';

// ════════════════════════════════════════════════════════════════
//  PALETA
// ════════════════════════════════════════════════════════════════

const COLORES = {
  Otto:    '#FF0066',
  Diesel:  '#1F78B4',
  Sabathé: '#33A02C',
};

const FONT_PLOTLY = 'Aptos, Segoe UI, sans-serif';

const layoutBase = (titulo, xLabel, yLabel, logX = false, logY = false) => ({
  title:  { text: titulo, font: { family: FONT_PLOTLY, size: 15 }, x: 0.05 },
  xaxis:  { title: xLabel, type: logX ? 'log' : 'linear', gridcolor: '#e8e8e8', tickfont: { family: FONT_PLOTLY } },
  yaxis:  { title: yLabel, type: logY ? 'log' : 'linear', gridcolor: '#e8e8e8', tickfont: { family: FONT_PLOTLY } },
  font:   { family: FONT_PLOTLY },
  plot_bgcolor:  '#fafafa',
  paper_bgcolor: 'rgba(0,0,0,0)',
  margin: { t: 50, r: 20, b: 50, l: 65 },
  legend: { font: { family: FONT_PLOTLY }, bgcolor: 'rgba(255,255,255,0.85)' },
  hovermode: 'closest',
});

const configBase = { responsive: true, displayModeBar: true, displaylogo: false,
  modeBarButtonsToRemove: ['lasso2d', 'select2d'] };

// ════════════════════════════════════════════════════════════════
//  HELPERS — GENERACIÓN DE CURVAS
// ════════════════════════════════════════════════════════════════

/**
 * Genera N puntos de la curva isentrópica entre dos estados.
 *   p = pa · (va/v)^k  ,  T = Ta · (va/v)^(k−1)
 *
 * @param {object} sA - Estado inicial {T, p, v}
 * @param {object} sB - Estado final   {T, p, v}
 * @param {number} k  - Exponente isentrópico
 * @param {number} N  - Número de puntos intermedios
 * @returns {{ v: number[], p: number[], T: number[], s: number[] }}
 */
const curvaIsentropica = (sA, sB, k, N = 60) => {
  const vs = [], ps = [], Ts = [];
  for (let i = 0; i <= N; i++) {
    const v = sA.v + (sB.v - sA.v) * (i / N);
    vs.push(v);
    ps.push(sA.p * Math.pow(sA.v / v, k));
    Ts.push(sA.T * Math.pow(sA.v / v, k - 1));
  }
  // s = cte para proceso isentrópico
  const s_val = Array(vs.length).fill(0);
  return { v: vs, p: ps, T: Ts, s: s_val };
};

/**
 * Genera puntos del proceso isocórico (línea vertical en p-v).
 * En T-s: q = cv·ΔT  →  s−s_ref = cv·ln(T/T_ref)
 */
const curvaIsocórica = (sA, sB, cv, s_ref, N = 40) => {
  const vs = [], ps = [], Ts = [], ss = [];
  for (let i = 0; i <= N; i++) {
    const T = sA.T + (sB.T - sA.T) * (i / N);
    const p = sA.p * (T / sA.T);           // Gay-Lussac
    vs.push(sA.v);
    ps.push(p);
    Ts.push(T);
    ss.push(s_ref + cv * Math.log(T / sA.T));
  }
  return { v: vs, p: ps, T: Ts, s: ss };
};

/**
 * Genera puntos del proceso isobárico (línea horizontal en p-v).
 * En T-s: q = cp·ΔT  →  s−s_ref = cp·ln(T/T_ref)
 */
const curvaIsobárica = (sA, sB, cp, s_ref, N = 40) => {
  const vs = [], ps = [], Ts = [], ss = [];
  for (let i = 0; i <= N; i++) {
    const T = sA.T + (sB.T - sA.T) * (i / N);
    const v = sA.v * (T / sA.T);           // Charles
    vs.push(v);
    ps.push(sA.p);
    Ts.push(T);
    ss.push(s_ref + cp * Math.log(T / sA.T));
  }
  return { v: vs, p: ps, T: Ts, s: ss };
};

// ════════════════════════════════════════════════════════════════
//  CONSTRUCCIÓN DE TRAZAS p-v y T-s
// ════════════════════════════════════════════════════════════════

/**
 * Construye los segmentos del ciclo como arrays {v, p, T, s}
 * listos para Plotly.
 *
 * Devuelve: { pv: {v, p}, ts: {T, s} }  (coordenadas del ciclo cerrado)
 */
const buildCicloTrace = (resultado, k) => {
  const st = resultado.estados;
  const cv = resultado.cv;
  const cp = resultado.cp;

  let segs_v = [], segs_p = [];
  let segs_T = [], segs_s = [];
  let s_cur = 0;  // entropía relativa acumulada

  const addSeg = (seg) => {
    segs_v.push(...seg.v);
    segs_p.push(...seg.p);
    segs_T.push(...seg.T);
    segs_s.push(...seg.s.map(ds => ds + s_cur));
    // avanzar s_cur al último valor
    s_cur += seg.s[seg.s.length - 1];
  };

  if (resultado.tipo === 'Otto') {
    // 1→2 isentrópico, 2→3 isocórico, 3→4 isentrópico, 4→1 isocórico
    addSeg(curvaIsentropica(st[0], st[1], k));
    const s_12 = 0;
    addSeg(curvaIsocórica(st[1], st[2], cv, s_cur));
    addSeg(curvaIsentropica(st[2], st[3], k));
    addSeg(curvaIsocórica(st[3], st[0], cv, s_cur));

  } else if (resultado.tipo === 'Diesel') {
    // 1→2 isen, 2→3 isobárico, 3→4 isen, 4→1 isocórico
    addSeg(curvaIsentropica(st[0], st[1], k));
    addSeg(curvaIsobárica(st[1], st[2], cp, s_cur));
    addSeg(curvaIsentropica(st[2], st[3], k));
    addSeg(curvaIsocórica(st[3], st[0], cv, s_cur));

  } else if (resultado.tipo === 'Sabathé') {
    // 1→2 isen, 2→3 isoc, 3→4 isobárico, 4→5 isen, 5→1 isocórico
    addSeg(curvaIsentropica(st[0], st[1], k));
    addSeg(curvaIsocórica(st[1], st[2], cv, s_cur));
    addSeg(curvaIsobárica(st[2], st[3], cp, s_cur));
    addSeg(curvaIsentropica(st[3], st[4], k));
    addSeg(curvaIsocórica(st[4], st[0], cv, s_cur));
  }

  // Cerrar el ciclo
  segs_v.push(segs_v[0]);
  segs_p.push(segs_p[0]);
  segs_T.push(segs_T[0]);
  segs_s.push(segs_s[0]);

  return {
    pv: { v: segs_v, p: segs_p },
    ts: { T: segs_T, s: segs_s },
  };
};

// ════════════════════════════════════════════════════════════════
//  DIAGRAMA p-v
// ════════════════════════════════════════════════════════════════

/**
 * Renderiza el diagrama p-v en el elemento con id dado.
 *
 * @param {string}  divId     - ID del div contenedor
 * @param {object}  resultado - Salida de calcularCiclo*()
 * @param {number}  k         - Exponente isentrópico
 * @param {boolean} logScale  - Escala logarítmica en ambos ejes
 */
const plotPV = (divId, resultado, k = 1.4, logScale = false) => {
  const { pv } = buildCicloTrace(resultado, k);
  const color = COLORES[resultado.tipo] || '#FF0066';

  const pMPa = pv.p.map(p => p / 1e6);
  const vLit = pv.v.map(v => v * 1000);

  // Traza de área rellena (trabajo neto)
  const areaTrace = {
    x: vLit, y: pMPa,
    fill: 'toself',
    fillcolor: color + '22',  // muy transparente
    line: { color: 'transparent' },
    hoverinfo: 'skip',
    showlegend: false,
    type: 'scatter',
  };

  // Traza del ciclo
  const cicloTrace = {
    x: vLit, y: pMPa,
    mode: 'lines',
    line: { color, width: 2.5 },
    name: `Ciclo ${resultado.tipo}`,
    type: 'scatter',
    hovertemplate: 'v = %{x:.4f} L/kg<br>p = %{y:.3f} MPa<extra></extra>',
  };

  // Marcadores de estados
  const estados = resultado.estados;
  const stTrace = {
    x: estados.map(s => s.v * 1000),
    y: estados.map(s => s.p / 1e6),
    mode: 'markers+text',
    marker: { color, size: 9, symbol: 'circle', line: { color: '#fff', width: 1.5 } },
    text: estados.map((_, i) => `  ${i + 1}`),
    textfont: { family: FONT_PLOTLY, size: 12, color: '#333' },
    textposition: 'top right',
    name: 'Estados',
    type: 'scatter',
    hovertemplate: 'Estado %{text}<br>v=%{x:.4f} L/kg<br>p=%{y:.3f} MPa<extra></extra>',
  };

  const layout = layoutBase(
    `Diagrama p-v — Ciclo ${resultado.tipo}`,
    'v  [L/kg]', 'p  [MPa]', logScale, logScale
  );

  // Anotaciones: η y PME
  layout.annotations = [{
    xref: 'paper', yref: 'paper', x: 0.98, y: 0.98,
    xanchor: 'right', yanchor: 'top',
    text: `η = ${(resultado.eta * 100).toFixed(2)} %<br>PME = ${(resultado.PME / 1e5).toFixed(3)} bar`,
    showarrow: false,
    bgcolor: 'rgba(255,255,255,0.85)',
    bordercolor: color, borderwidth: 1,
    font: { family: FONT_PLOTLY, size: 12 },
  }];

  Plotly.react(divId, [areaTrace, cicloTrace, stTrace], layout, configBase);
};

// ════════════════════════════════════════════════════════════════
//  DIAGRAMA T-s
// ════════════════════════════════════════════════════════════════

/**
 * Renderiza el diagrama T-s.
 * La escala de entropía es relativa (s=0 en estado 1).
 *
 * @param {string}  divId
 * @param {object}  resultado
 * @param {number}  k
 */
const plotTS = (divId, resultado, k = 1.4) => {
  const { ts } = buildCicloTrace(resultado, k);
  const color = COLORES[resultado.tipo] || '#FF0066';

  // Separar zona de adición de calor (T sube) de la de rechazo (T baja)
  // Se rellena el área total del ciclo
  const areaTrace = {
    x: ts.s, y: ts.T,
    fill: 'toself',
    fillcolor: color + '22',
    line: { color: 'transparent' },
    hoverinfo: 'skip', showlegend: false, type: 'scatter',
  };

  const cicloTrace = {
    x: ts.s, y: ts.T,
    mode: 'lines',
    line: { color, width: 2.5 },
    name: `Ciclo ${resultado.tipo}`,
    type: 'scatter',
    hovertemplate: 's = %{x:.1f} J/(kg·K)<br>T = %{y:.1f} K<extra></extra>',
  };

  const estados = resultado.estados;
  // Reconstruir s en los estados clave
  const stS = [0];  // s1 = 0
  let acc = 0;
  const cv = resultado.cv, cp = resultado.cp;
  for (let i = 0; i < estados.length - 1; i++) {
    const sA = estados[i], sB = estados[i + 1];
    // Determinar tipo de proceso
    if (Math.abs(sA.v - sB.v) < 1e-10) {
      acc += cv * Math.log(sB.T / sA.T);  // isocórico
    } else if (Math.abs(sA.p - sB.p) / sA.p < 1e-6) {
      acc += cp * Math.log(sB.T / sA.T);  // isobárico
    }
    // isentrópico: Δs = 0
    stS.push(acc);
  }

  const stTrace = {
    x: stS,
    y: estados.map(s => s.T),
    mode: 'markers+text',
    marker: { color, size: 9, symbol: 'circle', line: { color: '#fff', width: 1.5 } },
    text: estados.map((_, i) => `  ${i + 1}`),
    textfont: { family: FONT_PLOTLY, size: 12, color: '#333' },
    textposition: 'top right',
    name: 'Estados',
    type: 'scatter',
  };

  const layout = layoutBase(
    `Diagrama T-s — Ciclo ${resultado.tipo}`,
    's  [J/(kg·K)]', 'T  [K]'
  );

  // Líneas de referencia T_max y T1
  layout.shapes = [
    { type: 'line', xref: 'paper', x0: 0, x1: 1,
      yref: 'y', y0: estados[0].T, y1: estados[0].T,
      line: { color: '#aaa', width: 1, dash: 'dot' } },
  ];
  layout.annotations = [{
    xref: 'paper', yref: 'paper', x: 0.98, y: 0.98,
    xanchor: 'right', yanchor: 'top',
    text: `T₁ = ${estados[0].T.toFixed(1)} K<br>T_max = ${Math.max(...estados.map(s=>s.T)).toFixed(1)} K`,
    showarrow: false,
    bgcolor: 'rgba(255,255,255,0.85)',
    bordercolor: color, borderwidth: 1,
    font: { family: FONT_PLOTLY, size: 12 },
  }];

  Plotly.react(divId, [areaTrace, cicloTrace, stTrace], layout, configBase);
};

// ════════════════════════════════════════════════════════════════
//  CURVAS PARAMÉTRICAS
// ════════════════════════════════════════════════════════════════

/**
 * Grafica curvas η, PME y T_max vs. r para uno o más ciclos.
 *
 * @param {string}   divId
 * @param {object[]} curvasList  - Resultados de calcParametrico() con {tipo, ...curvas}
 */
const plotParametrico = (divId, curvasList) => {
  const trazas = curvasList.flatMap(cur => {
    const color = COLORES[cur.tipo] || '#888';
    return [
      { x: cur.r, y: cur.eta,  name: `${cur.tipo} η`,    line: { color, width: 2 },          type: 'scatter', mode: 'lines', yaxis: 'y'  },
      { x: cur.r, y: cur.PME,  name: `${cur.tipo} PME`,  line: { color, width: 2, dash:'dash' }, type: 'scatter', mode: 'lines', yaxis: 'y2' },
    ];
  });

  const layout = {
    title: { text: 'Análisis Paramétrico — η y PME vs. r', font: { family: FONT_PLOTLY, size: 15 } },
    xaxis:  { title: 'Relación de compresión r  [-]', gridcolor: '#e8e8e8', tickfont: { family: FONT_PLOTLY } },
    yaxis:  { title: 'η  [%]',   gridcolor: '#e8e8e8', tickfont: { family: FONT_PLOTLY } },
    yaxis2: { title: 'PME  [bar]', overlaying: 'y', side: 'right', tickfont: { family: FONT_PLOTLY }, gridcolor: 'transparent' },
    font:   { family: FONT_PLOTLY },
    plot_bgcolor: '#fafafa', paper_bgcolor: 'rgba(0,0,0,0)',
    margin: { t: 50, r: 70, b: 50, l: 60 },
    legend: { font: { family: FONT_PLOTLY }, bgcolor: 'rgba(255,255,255,0.85)' },
    hovermode: 'x unified',
  };

  Plotly.react(divId, trazas, layout, configBase);
};

/**
 * Grafica T_max vs. r para uno o más ciclos.
 */
const plotTmax = (divId, curvasList) => {
  const trazas = curvasList.map(cur => ({
    x: cur.r, y: cur.Tmax,
    name: `${cur.tipo}`,
    line: { color: COLORES[cur.tipo] || '#888', width: 2 },
    type: 'scatter', mode: 'lines',
    hovertemplate: 'r = %{x:.1f}<br>T_max = %{y:.0f} K<extra>' + cur.tipo + '</extra>',
  }));

  // Línea de alerta T_max = 2500 K
  trazas.push({
    x: [curvasList[0]?.r[0], curvasList[0]?.r.at(-1)],
    y: [2500, 2500],
    name: 'Límite T_max = 2500 K',
    line: { color: '#e74c3c', width: 1.5, dash: 'dot' },
    type: 'scatter', mode: 'lines',
    hoverinfo: 'skip',
  });

  const layout = layoutBase('T_max vs. r', 'Relación de compresión r  [-]', 'T_max  [K]');
  layout.hovermode = 'x unified';

  Plotly.react(divId, trazas, layout, configBase);
};

// ════════════════════════════════════════════════════════════════
//  COMPARACIÓN DE CICLOS (p-v superpuesto)
// ════════════════════════════════════════════════════════════════

/**
 * Superpone los diagramas p-v de los tres ciclos en un solo gráfico.
 *
 * @param {string}   divId
 * @param {object[]} resultados  - [resCicloOtto, resCicloDiesel, resCicloSabathe]
 * @param {number}   k
 */
const plotComparacion = (divId, resultados, k = 1.4) => {
  const trazas = [];

  for (const res of resultados) {
    const { pv } = buildCicloTrace(res, k);
    const color = COLORES[res.tipo] || '#888';
    trazas.push({
      x: pv.v.map(v => v * 1000),
      y: pv.p.map(p => p / 1e6),
      mode: 'lines',
      name: `Ciclo ${res.tipo}  (η=${(res.eta*100).toFixed(1)}%)`,
      line: { color, width: 2.5 },
      type: 'scatter',
      hovertemplate: `[${res.tipo}] v=%{x:.4f} L/kg  p=%{y:.3f} MPa<extra></extra>`,
    });
  }

  const layout = layoutBase('Comparación de Ciclos — Diagrama p-v', 'v  [L/kg]', 'p  [MPa]');
  layout.hovermode = 'closest';

  Plotly.react(divId, trazas, layout, configBase);
};

// ════════════════════════════════════════════════════════════════
//  EXPORTACIÓN (browser global)
// ════════════════════════════════════════════════════════════════

window.Charts = {
  plotPV,
  plotTS,
  plotParametrico,
  plotTmax,
  plotComparacion,
  COLORES,
};
